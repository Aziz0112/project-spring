package org.example.first_project4sae;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstProject4SaeApplicationTests {

    @Test
    void contextLoads() {
    }

}
