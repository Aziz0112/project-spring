package org.example.first_project4sae.Repositories;

import org.example.first_project4sae.Entities.Foyer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FoyerReposotory extends JpaRepository<Foyer, Long> {
}
