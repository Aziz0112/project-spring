package org.example.first_project4sae.Repositories;

import org.example.first_project4sae.Entities.Universite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UniversiteReposotory extends JpaRepository<Universite, Long> {
}
