package org.example.first_project4sae.Entities;

public enum TypeChambre {

    SIMPLE, DOUBLE, TRIPLE
}
